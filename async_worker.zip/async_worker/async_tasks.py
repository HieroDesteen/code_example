from datetime import datetime

from apps.async_worker.archivation import ArchivationManager
from apps.engine.models import Task, Project
from apps.engine.log import slogger


def streams_tasks(scheduler):
    scheduler.schedule(
        scheduled_time=datetime.utcnow(),
        func=archivation_queue,
        interval=1800,  # in seconds
    )


def archivation_queue():
    slogger.glob.info('Start archivation queue.')
    am = ArchivationManager()
    for project in Project.objects.all():
        arch_worker = am.archivation_worker(project)
        if arch_worker:
            slogger.glob.info('Project #{} in processing.'.format(project.id))
            arch_worker.project_exec(project)

    for task in Task.objects.all():
        arch_worker = am.archivation_worker(task)
        if arch_worker:
            slogger.glob.info('Task #{} in processing.'.format(task.id))
            arch_worker.task_exec(task)

