default_app_config = 'apps.async_worker.apps.AsyncWorkerConfig'
