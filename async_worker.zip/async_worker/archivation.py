import os
import shutil
import zipfile

from django.conf import settings

from apps.async_worker import storage_clients
from apps.engine import choices


class Archivation:
    def __init__(self):
        self.curr_task_state = None

    def task_exec(self, task):
        raise NotImplementedError()

    def project_exec(self, project):
        raise NotImplementedError()


class Archiving(Archivation):
    def _archive_upload(self, task):
        storage_client = storage_clients.get_storage_client(storage_client_type=self.curr_task_state.dest_location)
        archive_path = task.get_task_archive_path()
        with storage_client as sc:
            sc.upload('{}/{}.zip'.format(archive_path, task.id), os.path.join(storage_client.archive_root, '{}.zip'.format(task.id)))

        self.curr_task_state.update_location()

    def _archive_data(self, task):
        upload_data = task.get_upload_dirname()
        if os.path.exists(upload_data):
            shutil.rmtree(upload_data)
        data = task.get_data_dirname()
        archive_path = task.get_task_archive_path()
        os.makedirs(archive_path, exist_ok=True)

        def _zipdir(path, ziph):
            for root, dirs, files in os.walk(path):
                for file in files:
                    ziph.write(os.path.join(root, file))

        zipf = zipfile.ZipFile(archive_path + '/{}.zip'.format(task.id), 'w', zipfile.ZIP_DEFLATED)
        _zipdir(data, zipf)
        zipf.close()
        shutil.rmtree(data)

    def _archiving(self, task):
        self.curr_task_state.set_in_arch_progress_status()
        self._archive_data(task)
        if self.curr_task_state.location != self.curr_task_state.dest_location:
            self._archive_upload(task)

        self.curr_task_state.set_archived_status()

    def task_exec(self, task):
        self.curr_task_state = task.state
        try:
            self._archiving(task)
        except Exception as e:
            self.curr_task_state.set_except_arch_status()

    def project_exec(self, project):
        for task in project.tasks:
            self.curr_task_state = task.state
            try:
                self._archiving(task)
            except Exception as e:
                self.curr_task_state.set_except_arch_status()


class Unarchiving(Archivation):
    def project_exec(self, project):
        for task in project.tasks:
            self.curr_task_state = task.state
            try:
                self._unarchiving(task)
            except Exception as e:
                self.curr_task_state.set_except_unarch_status()

    def task_exec(self, task):
        self.curr_task_state = task.state
        try:
            self._unarchiving(task)
        except Exception as e:
            self.curr_task_state.set_except_unarch_status()

    def _unarchiving(self, task):
        self.curr_task_state.set_in_unarch_progress_status()
        if self.curr_task_state.location != storage_clients.StorageClientsTypes.LOCAL:
            self._dump_archive(task)
        self._unarchive_data(task)

        self.curr_task_state.set_active_status()

    def _unarchive_data(self, task):
        tmp_dir = os.path.join(task.get_task_dirname(), 'tmp')
        os.makedirs(tmp_dir, exist_ok=True)
        with zipfile.ZipFile(task.get_task_archive_path() + '/{}.zip'.format(task.id), 'r') as archive:
            archive.extractall(tmp_dir)

        os.makedirs(task.get_data_dirname(), exist_ok=True)
        old_path = os.path.join(tmp_dir, task.get_data_dirname())
        os.rename(old_path, task.get_data_dirname())
        shutil.rmtree(tmp_dir)

    def _dump_archive(self, task):
        storage_client = storage_clients.get_storage_client(storage_client_type=self.curr_task_state.location)
        archive_path = task.get_task_archive_path()
        with storage_client as sc:
            sc.download(os.path.join(storage_client.archive_root, '{}.zip'.format(task.id)), '{}/{}.zip'.format(archive_path, task.id))

        self.curr_task_state.set_local_location()


class ArchivationManager:

    def enqueue_for_archiving(self, instance, dst_location):
        state = instance.state
        if state.status == choices.StateChoice.ACTIVE:
            state.status = choices.StateChoice.IN_ARCH_Q
            state.dest_location = dst_location
            state.save()
        else:
            raise Exception("Can't enqueue this task for archiving. The task status must be active.")

    def enqueue_for_unarchiving(self, instance):
        state = instance.state
        if state.status == choices.StateChoice.ARCHIVED:
            state.status = choices.StateChoice.IN_UNARCH_Q
            state.dest_location = choices.StorageClientsTypes.LOCAL
            state.save()
        else:
            raise Exception("Can't enqueue this task for unarchiving. The task status must be archived.")


    def archivation_worker(self, instance):
        if instance.state.status == choices.StateChoice.IN_ARCH_Q:
            return Archiving()
        elif instance.state.status == choices.StateChoice.IN_UNARCH_Q:
            return Unarchiving()
        else:
            return None
