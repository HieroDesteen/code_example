import pysftp
import os
import shutil
import stat
from enum import Enum

from django.conf import settings

from apps.engine.serializers import FileInfoSerializer
from apps.engine.choices import StorageClientsTypes


class StorageClient:
    def __init__(self):
        self._conn = None

    def __enter__(self):
        raise NotImplementedError()

    def __exit__(self, exc_type, exc_val, exc_tb):
        raise NotImplementedError()

    def download(self, source_path, dest_path):
        raise NotImplementedError()

    def upload(self, source_path, dest_path):
        raise NotImplementedError()

    def files_list(self, path):
        raise NotImplementedError()


class FTPStorageClient(StorageClient):
    def __init__(self):
        self._host = settings.FTP_HOSTNAME
        self._username = settings.FTP_USERNAME
        self._password = settings.FTP_PASSWORD
        self.archive_root = settings.FTP_ARCHIVE_ROOT

        super().__init__()

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return True

    def connect(self):
        cnopts = pysftp.CnOpts()
        cnopts.hostkeys.load(settings.KNOWN_HOSTS_ROOT)
        self._conn = pysftp.Connection(host=self._host, username=self._username, password=self._password, cnopts=cnopts)

    def close(self):
        self._conn.close()

    def files_list(self, dir_path='/'):
        data = []

        for item in self._conn.listdir_attr(dir_path):
            data.append({
                "name": item.filename,
                "type": "DIR" if stat.S_ISDIR(item.st_mode) else "REG"
            })
        serializer = FileInfoSerializer(many=True, data=data)
        if serializer.is_valid(raise_exception=True):
            return serializer.data

    def download(self, source_path, dest_path):
        if self._conn.isfile(source_path):
            self._conn.get(source_path, dest_path, preserve_mtime=True)
        else:
            self._conn.get_d(source_path, dest_path, preserve_mtime=True)

    def upload(self, source_path, dest_path):
        if os.path.isfile(source_path):
            self._conn.put(source_path, dest_path)
        else:
            self._conn.put_d(source_path, dest_path)


class LocalStorageClient(StorageClient):
    def __init__(self):
        self._local_path = settings.SHARE_ROOT
        self.archive_root = settings.ARCHIVED_DATA
        super().__init__()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return True

    def files_list(self, path='/'):

        if path.startswith("/"):
            path = path[1:]
        directory = os.path.abspath(os.path.join(settings.SHARE_ROOT, path))

        if directory.startswith(settings.SHARE_ROOT) and os.path.isdir(directory):
            data = []
            content = os.scandir(directory)
            for entry in content:
                entry_type = None
                if entry.is_file():
                    entry_type = "REG"
                elif entry.is_dir():
                    entry_type = "DIR"

                if entry_type:
                    data.append({"name": entry.name, "type": entry_type})

            serializer = FileInfoSerializer(many=True, data=data)
            if serializer.is_valid(raise_exception=True):
                return serializer.data
        else:
            raise Exception("{} is an invalid directory".format(path))

    def download(self, dest_path, source_path=None):
        shutil.copy2(src=self._local_path, dst=dest_path)

    def upload(self, source_path, dest_path=None):
        shutil.copy2(src=source_path, dst=self._local_path)


def get_storage_client(storage_client_type=StorageClientsTypes.FTP):
    if storage_client_type == StorageClientsTypes.FTP:
        return FTPStorageClient()
    elif storage_client_type == StorageClientsTypes.LOCAL:
        return LocalStorageClient()
