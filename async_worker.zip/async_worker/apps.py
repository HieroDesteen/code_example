from django.apps import AppConfig
import django_rq

class AsyncWorkerConfig(AppConfig):
    name = 'apps.async_worker'

    def ready(self):
        from apps.async_worker.async_tasks import streams_tasks
        scheduler = django_rq.get_scheduler('default')

        for job in scheduler.get_jobs():
            job.delete()

        streams_tasks(scheduler)
